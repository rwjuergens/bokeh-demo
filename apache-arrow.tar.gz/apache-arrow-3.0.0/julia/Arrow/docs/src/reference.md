# API Reference

```@autodocs
Modules = [Arrow]
Order   = [:type, :function]
```